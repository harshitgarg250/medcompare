// components/AIChat/AIChat.jsx

import React, { useState, useEffect, useRef } from 'react'
import axios from 'axios'
import styles from './AIChat.module.css'

const AIChat = () => {
  // =========================================================
  // STATE
  // =========================================================

  const [conversations, setConversations] = useState([])
  const [activeConversation, setActiveConversation] = useState(null)
  const [messages, setMessages] = useState([])
  const [question, setQuestion] = useState('')
  const [loading, setLoading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [loadingConversations, setLoadingConversations] = useState(true)

  const messagesEndRef = useRef(null)
  const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:5001'

  // =========================================================
  // AUTO SCROLL TO BOTTOM
  // =========================================================

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // =========================================================
  // FETCH ALL CONVERSATIONS
  // =========================================================

  const fetchConversations = async () => {
    try {
      setLoadingConversations(true)
      const token = localStorage.getItem('token')
      const response = await axios.get(
        `${API_BASE}/api/ai/conversations`,
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )
      setConversations(response.data.conversations)
    } catch (error) {
      console.error('Failed to fetch conversations:', error)
      alert('Failed to load conversations')
    } finally {
      setLoadingConversations(false)
    }
  }

  // =========================================================
  // FETCH CONVERSATION MESSAGES
  // =========================================================

  const fetchConversation = async (conversationId) => {
    try {
      const token = localStorage.getItem('token')
      const response = await axios.get(
        `${API_BASE}/api/ai/conversations/${conversationId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )
      setActiveConversation(response.data.conversation)
      setMessages(response.data.conversation.messages)
    } catch (error) {
      console.error('Failed to fetch conversation:', error)
      alert('Failed to load conversation')
    }
  }

  // =========================================================
  // CREATE NEW CONVERSATION
  // =========================================================

  const createNewConversation = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await axios.post(
        `${API_BASE}/api/ai/conversations`,
        { title: 'New Conversation' },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      const newConversation = response.data.conversation
      setConversations([newConversation, ...conversations])
      setActiveConversation(newConversation)
      setMessages([])
      setQuestion('')
    } catch (error) {
      console.error('Failed to create conversation:', error)
      alert('Failed to create conversation')
    }
  }

  // =========================================================
  // DELETE CONVERSATION
  // =========================================================

  const deleteConversation = async (conversationId, e) => {
    e.stopPropagation()

    if (!window.confirm('Are you sure? This cannot be undone.')) return

    try {
      const token = localStorage.getItem('token')
      await axios.delete(
        `${API_BASE}/api/ai/conversations/${conversationId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      const updated = conversations.filter(c => c.id !== conversationId)
      setConversations(updated)

      if (activeConversation?.id === conversationId) {
        setActiveConversation(null)
        setMessages([])
      }
    } catch (error) {
      console.error('Failed to delete conversation:', error)
      alert('Failed to delete conversation')
    }
  }

  // =========================================================
  // SEND MESSAGE / ASK AI
  // =========================================================

  const handleAskAI = async (e) => {
    e.preventDefault()

    if (!question.trim() || !activeConversation) return

    const userMessage = {
      role: 'user',
      message: question,
      createdAt: new Date()
    }

    // Add user message to UI immediately
    setMessages([...messages, userMessage])
    setQuestion('')
    setLoading(true)

    try {
      const token = localStorage.getItem('token')
      const response = await axios.post(
        `${API_BASE}/api/ai/conversations/${activeConversation.id}/ask`,
        { question: question.trim() },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      const aiMessage = {
        role: 'assistant',
        message: response.data.answer,
        language: response.data.language,
        createdAt: new Date()
      }

      setMessages(prev => [...prev, aiMessage])

      // Refresh conversations to update timestamps
      fetchConversations()
    } catch (error) {
      console.error('Failed to get AI response:', error)
      const errorMessage = {
        role: 'assistant',
        message: error.response?.data?.error || 'Sorry, something went wrong. Please try again.',
        createdAt: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setLoading(false)
    }
  }

  // =========================================================
  // EFFECTS
  // =========================================================

  useEffect(() => {
    fetchConversations()
  }, [])

  // =========================================================
  // RENDER
  // =========================================================

  return (
    <div className={styles.container}>
      {/* =========================================================
          SIDEBAR - CONVERSATIONS LIST
          ========================================================= */}
      <div className={`${styles.sidebar} ${sidebarOpen ? styles.open : ''}`}>
        <div className={styles.sidebarHeader}>
          <h2>💬 MedCompare AI</h2>
          <button
            className={styles.closeBtn}
            onClick={() => setSidebarOpen(false)}
            title="Close sidebar"
          >
            ✕
          </button>
        </div>

        <button
          className={styles.newChatBtn}
          onClick={createNewConversation}
        >
          + New Conversation
        </button>

        <div className={styles.conversationsList}>
          {loadingConversations ? (
            <div className={styles.loading}>Loading...</div>
          ) : conversations.length === 0 ? (
            <p className={styles.empty}>No conversations yet</p>
          ) : (
            conversations.map(conv => (
              <div
                key={conv.id}
                className={`${styles.conversationItem} ${
                  activeConversation?.id === conv.id ? styles.active : ''
                }`}
                onClick={() => fetchConversation(conv.id)}
                title={conv.title}
              >
                <div className={styles.convTitle}>{conv.title}</div>
                <div className={styles.convMeta}>
                  <span className={styles.convTime}>
                    {new Date(conv.createdAt).toLocaleDateString()}
                  </span>
                  <span className={styles.convCount}>
                    {conv._count?.messages || 0} messages
                  </span>
                </div>
                <button
                  className={styles.deleteBtn}
                  onClick={(e) => deleteConversation(conv.id, e)}
                  title="Delete conversation"
                >
                  🗑️
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* =========================================================
          MAIN CHAT AREA
          ========================================================= */}
      <div className={styles.chatArea}>
        {/* HEADER */}
        <div className={styles.chatHeader}>
          <button
            className={styles.hamburger}
            onClick={() => setSidebarOpen(!sidebarOpen)}
            title="Toggle sidebar"
          >
            ☰
          </button>
          <h1>
            {activeConversation?.title || 'Select a conversation'}
          </h1>
        </div>

        {/* MESSAGES */}
        <div className={styles.messagesContainer}>
          {!activeConversation ? (
            <div className={styles.noConversation}>
              <div className={styles.emptyState}>
                <h2>Welcome to MedCompare Assistant 🏥</h2>
                <p>Ask about hospitals, medical tests, and health information</p>
                <button
                  className={styles.startBtn}
                  onClick={createNewConversation}
                >
                  Start New Conversation
                </button>
              </div>
            </div>
          ) : (
            <>
              {messages.length === 0 ? (
                <div className={styles.emptyChat}>
                  <p>Start asking your questions about hospitals and tests!</p>
                </div>
              ) : (
                messages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`${styles.message} ${styles[msg.role]}`}
                  >
                    <div className={styles.messageContent}>
                      {msg.message}
                    </div>
                    <div className={styles.messageTime}>
                      {new Date(msg.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </div>
                  </div>
                ))
              )}
              {loading && (
                <div className={`${styles.message} ${styles.assistant}`}>
                  <div className={styles.typing}>
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* INPUT FORM */}
        {activeConversation && (
          <form className={styles.inputForm} onSubmit={handleAskAI}>
            <input
              type="text"
              placeholder="Ask about hospitals, tests, health..."
              value={question}
              onChange={e => setQuestion(e.target.value)}
              disabled={loading}
              autoFocus
            />
            <button
              type="submit"
              disabled={loading || !question.trim()}
              title={!question.trim() ? 'Type a question first' : 'Send message'}
            >
              {loading ? '⏳' : '→'}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}

export default AIChat